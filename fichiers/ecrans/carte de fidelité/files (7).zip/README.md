# Module "Carte de fidélité" + "Marketing / Retargeting" — Kassa

## 1. Carte de fidélité (existant)

Formulaire client (nom, téléphone, adresse optionnelle) → génération de
carte + QR code → aperçu visuel → **export PDF imprimable/partageable**.

```
lib/models/loyalty_card.dart
lib/screens/loyalty_card_form_screen.dart
lib/screens/loyalty_card_result_screen.dart   # Imprimer/Partager en PDF
lib/widgets/loyalty_card_widget.dart
lib/services/loyalty_card_pdf_service.dart    # Génère le PDF (pdf + printing)
```

## 2. Marketing / Retargeting clients (nouveau)

Une fois la carte imprimée/envoyée, le client reste enregistré dans
l'app (liste déjà existante côté Kassa — voir note d'intégration
ci-dessous). Le vendeur peut ensuite :

1. **Choisir un segment de clients** : tous les clients, pas revenus
   depuis 2 mois / 6 mois, clients fidèles (achats répétés), clients
   venus une seule fois et jamais revenus.
2. **Choisir un produit en promotion** (optionnel, tiré du catalogue).
3. **Rédiger un message**.
4. **Choisir le canal** : WhatsApp ou SMS.
5. **Lancer l'envoi**.

```
lib/models/customer_profile.dart          # Client + historique visites/achats
lib/models/product_ref.dart               # Référence produit (catalogue)
lib/models/marketing_campaign.dart        # Segment, canal, campagne
lib/services/customer_segmentation_service.dart
lib/services/campaign_sender_service.dart # Envoi WhatsApp/SMS
lib/screens/marketing_campaign_screen.dart# Écran de composition + envoi
lib/widgets/customer_segment_selector.dart
lib/widgets/product_picker.dart
lib/widgets/channel_selector.dart
```

### ⚠️ Point important : l'envoi automatique en masse a une limite technique

Ni WhatsApp ni SMS ne permettent à une app tierce d'envoyer des messages
**silencieusement, sans intervention humaine**, en dehors d'une vraie
intégration API :

- **WhatsApp** : le lien `wa.me` ouvre la conversation avec le message
  pré-rempli, mais WhatsApp exige que l'utilisateur appuie lui-même sur
  "Envoyer" — impossible à automatiser depuis une app externe.
- **SMS** : pareil, surtout sur iPhone où Apple interdit l'envoi de SMS
  sans interaction utilisateur.

**Ce qui est livré maintenant (`AssistedQueueCampaignSender`)** : un mode
"file d'attente assistée" qui fonctionne dès aujourd'hui, sans backend.
Kassa ouvre WhatsApp/SMS pré-rempli pour chaque client sélectionné, le
vendeur confirme l'envoi (1 tap), puis passe au client suivant depuis
Kassa. Rapide en pratique, mais pas 100% automatique.

**Pour un vrai envoi automatique en masse (0 tap par client)**, il faut
brancher une vraie API, ce qui nécessite un backend :

- **WhatsApp Business API** (Meta Cloud API directement, ou un
  prestataire comme Twilio ou 360dialog) : le numéro de la boutique doit
  être enregistré en WhatsApp Business, l'entreprise vérifiée auprès de
  Meta, et les messages marketing utilisent des "templates" pré-approuvés
  quand on écrit en dehors d'une conversation déjà ouverte (fenêtre de 24h).
- **Passerelle SMS** (ex: Africa's Talking — bien implanté en Afrique,
  ou Twilio) avec un "Sender ID" au nom de la boutique.

L'architecture est prête pour ça : `CampaignSenderService` est une
interface ; il suffira d'écrire une implémentation `ApiCampaignSender`
(gabarit commenté dans `campaign_sender_service.dart`) qui appelle votre
backend, sans toucher aux écrans.

## Dépendances à ajouter dans `pubspec.yaml` de Kassa

```yaml
dependencies:
  qr_flutter: ^4.1.0
  pdf: ^3.11.1
  printing: ^5.13.4
  path_provider: ^2.1.4
  url_launcher: ^6.3.1
```

Puis `flutter pub get`.

## Intégration dans Kassa

1. Copier `lib/models`, `lib/screens`, `lib/widgets`, `lib/services` dans
   la structure du monorepo, en respectant vos conventions de packages
   (foundations → domaine métier partagé → présentation).
2. **Carte de fidélité** : bouton "Nouveau client fidélité" → ouvre
   `LoyaltyCardFormScreen`. Après création, l'écran de résultat propose
   directement "Imprimer" et "Partager" en PDF.
3. **Marketing** : bouton "Retargeting clients" dans le menu → ouvre
   `MarketingCampaignScreen(allCustomers: ..., products: ...)` en lui
   passant :
   - la liste de vos clients existants, mappée vers `CustomerProfile`
     (via `CustomerProfile.fromLoyaltyCard(card, lastVisitDate: ..., purchaseCount: ...)`
     ou un mapping équivalent depuis votre modèle client actuel) ;
   - la liste des produits du catalogue à promouvoir, mappée vers
     `ProductRef`.
4. Le `lastVisitDate` et `purchaseCount` de chaque client doivent venir
   de votre historique de ventes/passages existant — c'est ce qui
   alimente les filtres "2 mois / 6 mois / achats répétés / jamais revenus".

## Points restants à brancher

- Persistance réelle de la carte de fidélité (callback `onCardCreated`).
- Mapping de vos clients existants vers `CustomerProfile` (historique
  réel de visites/achats).
- Mapping du catalogue produit existant vers `ProductRef`.
- `ApiCampaignSender` (WhatsApp Business API + passerelle SMS) le jour
  où vous voulez un envoi 100% automatique en masse.
