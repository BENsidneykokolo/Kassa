import 'package:url_launcher/url_launcher.dart';
import '../models/customer_profile.dart';
import '../models/marketing_campaign.dart';

/// Résultat d'un envoi individuel, utilisé pour suivre la progression
/// de la campagne dans l'UI.
class CampaignSendStep {
  final CustomerProfile customer;
  final bool launched;
  const CampaignSendStep({required this.customer, required this.launched});
}

/// Interface commune pour tout mécanisme d'envoi de campagne.
/// Deux implémentations sont fournies :
/// - [AssistedQueueCampaignSender] : fonctionne immédiatement, sans backend,
///   mais demande au vendeur de confirmer l'envoi client par client
///   (limitation imposée par WhatsApp / SMS, voir README).
/// - Une future implémentation "API" (WhatsApp Business API / passerelle
///   SMS) pourra implémenter la même interface pour un envoi 100%
///   automatique en masse, sans rien changer côté écran.
abstract class CampaignSenderService {
  /// Retourne le nombre d'étapes prévues (= nombre de destinataires).
  int stepCount(MarketingCampaign campaign) => campaign.recipients.length;

  /// Envoie le message au destinataire donné (ouvre l'app externe pour le
  /// mode assisté, ou appelle l'API pour un envoi automatique).
  Future<CampaignSendStep> sendToCustomer(
    MarketingCampaign campaign,
    CustomerProfile customer,
  );
}

/// Mode "file d'attente assistée" : pour chaque client sélectionné,
/// ouvre WhatsApp (lien wa.me) ou l'appli SMS avec le message
/// pré-rempli. Le vendeur doit appuyer sur "Envoyer" dans l'app
/// externe puis revenir sur Kassa pour passer au client suivant.
///
/// C'est la seule méthode utilisable sans intégration backend :
/// WhatsApp et iOS/Android n'autorisent pas l'envoi programmatique
/// silencieux depuis une app tierce.
class AssistedQueueCampaignSender implements CampaignSenderService {
  @override
  int stepCount(MarketingCampaign campaign) => campaign.recipients.length;

  @override
  Future<CampaignSendStep> sendToCustomer(
    MarketingCampaign campaign,
    CustomerProfile customer,
  ) async {
    final uri = campaign.channel == MarketingChannel.whatsapp
        ? _whatsappUri(customer.phoneNumber, campaign.message)
        : _smsUri(customer.phoneNumber, campaign.message);

    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    return CampaignSendStep(customer: customer, launched: launched);
  }

  Uri _whatsappUri(String phoneNumber, String message) {
    final normalized = _normalizePhone(phoneNumber);
    return Uri.parse('https://wa.me/$normalized?text=${Uri.encodeComponent(message)}');
  }

  Uri _smsUri(String phoneNumber, String message) {
    // 'sms:' scheme ouvre l'application SMS native avec le corps pré-rempli.
    return Uri(
      scheme: 'sms',
      path: phoneNumber,
      queryParameters: {'body': message},
    );
  }

  String _normalizePhone(String phoneNumber) {
    return phoneNumber.replaceAll(RegExp(r'[^0-9+]'), '');
  }
}

/// -----------------------------------------------------------------------
/// GABARIT pour le vrai envoi en masse automatique (à implémenter côté
/// backend). Non fonctionnel tel quel : à brancher sur un fournisseur.
///
/// Pour WhatsApp : WhatsApp Business API (Meta Cloud API, ou un
/// Business Solution Provider comme Twilio / 360dialog). Nécessite :
///   - le numéro de la boutique enregistré en WhatsApp Business,
///   - une vérification de l'entreprise auprès de Meta,
///   - des templates de message approuvés pour les envois marketing
///     hors fenêtre de conversation de 24h.
///
/// Pour SMS : une passerelle SMS (ex: Africa's Talking, Twilio) avec
/// un "Sender ID" configuré au nom de la boutique.
///
/// class ApiCampaignSender implements CampaignSenderService {
///   final String apiBaseUrl;
///   ApiCampaignSender(this.apiBaseUrl);
///
///   @override
///   Future<CampaignSendStep> sendToCustomer(
///     MarketingCampaign campaign,
///     CustomerProfile customer,
///   ) async {
///     // POST vers votre backend, qui relaie vers l'API WhatsApp
///     // Business ou la passerelle SMS, puis retourne le statut.
///     throw UnimplementedError('Brancher sur le backend Yabisso');
///   }
/// }
/// -----------------------------------------------------------------------
