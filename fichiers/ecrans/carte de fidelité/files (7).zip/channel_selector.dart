import 'package:flutter/material.dart';
import '../models/marketing_campaign.dart';

class ChannelSelector extends StatelessWidget {
  final MarketingChannel selected;
  final ValueChanged<MarketingChannel> onChanged;

  const ChannelSelector({
    super.key,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _ChannelCard(
            icon: Icons.chat_bubble_rounded,
            label: 'WhatsApp',
            color: const Color(0xFF25D366),
            isSelected: selected == MarketingChannel.whatsapp,
            onTap: () => onChanged(MarketingChannel.whatsapp),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ChannelCard(
            icon: Icons.sms_rounded,
            label: 'SMS',
            color: Theme.of(context).colorScheme.primary,
            isSelected: selected == MarketingChannel.sms,
            onTap: () => onChanged(MarketingChannel.sms),
          ),
        ),
      ],
    );
  }
}

class _ChannelCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;

  const _ChannelCard({
    required this.icon,
    required this.label,
    required this.color,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? color : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
          color: isSelected ? color.withOpacity(0.08) : null,
        ),
        child: Column(
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
