import 'loyalty_card.dart';

/// Profil client utilisé par le module marketing/retargeting.
///
/// Ce modèle étend les infos de la carte de fidélité avec les
/// statistiques nécessaires à la segmentation (dernière visite,
/// nombre d'achats). Si la liste des clients existe déjà côté Kassa,
/// il suffit d'adapter [fromLoyaltyCard] (ou de fournir un mapper
/// équivalent) pour la faire correspondre à votre modèle existant.
class CustomerProfile {
  final String cardId;
  final String name;
  final String phoneNumber;
  final String? address;
  final DateTime? lastVisitDate;
  final int purchaseCount;

  const CustomerProfile({
    required this.cardId,
    required this.name,
    required this.phoneNumber,
    this.address,
    this.lastVisitDate,
    this.purchaseCount = 0,
  });

  factory CustomerProfile.fromLoyaltyCard(
    LoyaltyCard card, {
    DateTime? lastVisitDate,
    int purchaseCount = 0,
  }) {
    return CustomerProfile(
      cardId: card.id,
      name: card.customerName,
      phoneNumber: card.phoneNumber,
      address: card.address,
      lastVisitDate: lastVisitDate,
      purchaseCount: purchaseCount,
    );
  }

  /// Nombre de jours écoulés depuis la dernière visite (ou null si inconnu).
  int? get daysSinceLastVisit {
    if (lastVisitDate == null) return null;
    return DateTime.now().difference(lastVisitDate!).inDays;
  }

  bool get hasNeverReturned => purchaseCount <= 1;
}
