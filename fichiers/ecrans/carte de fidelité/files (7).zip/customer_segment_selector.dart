import 'package:flutter/material.dart';
import '../models/marketing_campaign.dart';

class CustomerSegmentSelector extends StatelessWidget {
  final CustomerSegment? selected;
  final ValueChanged<CustomerSegment> onSelected;

  const CustomerSegmentSelector({
    super.key,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final segments = CustomerSegment.presets();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: segments.map((segment) {
        final isSelected = selected?.label == segment.label;
        return ChoiceChip(
          label: Text(segment.label),
          selected: isSelected,
          onSelected: (_) => onSelected(segment),
        );
      }).toList(),
    );
  }
}
