import '../models/customer_profile.dart';
import '../models/marketing_campaign.dart';

/// Filtre une liste de [CustomerProfile] selon un [CustomerSegment].
class CustomerSegmentationService {
  List<CustomerProfile> filter(
    List<CustomerProfile> customers,
    CustomerSegment segment,
  ) {
    switch (segment.type) {
      case SegmentType.all:
        return customers;

      case SegmentType.inactiveSince:
        final threshold = segment.inactiveDuration!;
        return customers.where((c) {
          final days = c.daysSinceLastVisit;
          return days != null && days >= threshold.inDays;
        }).toList();

      case SegmentType.repeatCustomers:
        return customers.where((c) => c.purchaseCount >= 2).toList();

      case SegmentType.oneTimeNoReturn:
        final threshold = segment.inactiveDuration ?? const Duration(days: 60);
        return customers.where((c) {
          final days = c.daysSinceLastVisit;
          return c.hasNeverReturned && days != null && days >= threshold.inDays;
        }).toList();
    }
  }
}
