import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import '../models/loyalty_card.dart';

/// Génère un PDF imprimable de la carte de fidélité (même format
/// visuel que la carte affichée dans l'app), et permet de
/// l'imprimer ou de le partager directement (ex: vers WhatsApp).
class LoyaltyCardPdfService {
  Future<Uint8List> _buildPdfBytes(LoyaltyCard card, {String storeName = 'Yabisso · Kassa'}) async {
    final doc = pw.Document();

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a6.landscape,
        margin: const pw.EdgeInsets.all(16),
        build: (context) {
          return pw.Container(
            padding: const pw.EdgeInsets.all(18),
            decoration: pw.BoxDecoration(
              color: PdfColor.fromInt(0xFF17303B),
              borderRadius: pw.BorderRadius.circular(14),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          storeName,
                          style: pw.TextStyle(
                            color: PdfColors.white,
                            fontSize: 14,
                            fontWeight: pw.FontWeight.bold,
                          ),
                        ),
                        pw.SizedBox(height: 2),
                        pw.Text(
                          'CARTE DE FIDELITE',
                          style: pw.TextStyle(
                            color: PdfColors.grey300,
                            fontSize: 8,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                pw.Spacer(),
                pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Expanded(
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text(
                            card.customerName.toUpperCase(),
                            style: pw.TextStyle(
                              color: PdfColors.white,
                              fontSize: 13,
                              fontWeight: pw.FontWeight.bold,
                            ),
                          ),
                          pw.SizedBox(height: 3),
                          pw.Text(
                            card.phoneNumber,
                            style: const pw.TextStyle(color: PdfColors.grey200, fontSize: 10),
                          ),
                          if (card.address != null && card.address!.trim().isNotEmpty)
                            pw.Text(
                              card.address!,
                              style: const pw.TextStyle(color: PdfColors.grey400, fontSize: 8),
                            ),
                          pw.SizedBox(height: 6),
                          pw.Text(
                            card.id,
                            style: const pw.TextStyle(color: PdfColors.grey500, fontSize: 7),
                          ),
                        ],
                      ),
                    ),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(6),
                      color: PdfColors.white,
                      child: pw.BarcodeWidget(
                        barcode: pw.Barcode.qrCode(),
                        data: card.qrPayload,
                        width: 70,
                        height: 70,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );

    return doc.save();
  }

  /// Génère le PDF et l'enregistre localement (utile pour l'archivage
  /// ou pour joindre le fichier à un partage). Retourne le fichier créé.
  Future<File> generateAndSave(LoyaltyCard card, {String storeName = 'Yabisso · Kassa'}) async {
    final bytes = await _buildPdfBytes(card, storeName: storeName);
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/carte_fidelite_${card.id}.pdf');
    await file.writeAsBytes(bytes);
    return file;
  }

  /// Ouvre la boîte de dialogue d'impression système avec la carte.
  Future<void> printCard(LoyaltyCard card, {String storeName = 'Yabisso · Kassa'}) async {
    final bytes = await _buildPdfBytes(card, storeName: storeName);
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  /// Partage directement le PDF (ex: pour l'envoyer par WhatsApp au client).
  Future<void> shareCard(LoyaltyCard card, {String storeName = 'Yabisso · Kassa'}) async {
    final bytes = await _buildPdfBytes(card, storeName: storeName);
    await Printing.sharePdf(bytes: bytes, filename: 'carte_fidelite_${card.id}.pdf');
  }
}
