import 'package:flutter/material.dart';
import '../models/loyalty_card.dart';
import '../services/loyalty_card_pdf_service.dart';
import '../widgets/loyalty_card_widget.dart';

/// Écran affichant la carte de fidélité générée (avec QR code) une fois
/// le formulaire validé. Prévu pour accueillir plus tard des actions
/// comme "Imprimer", "Partager" ou "Enregistrer en image".
class LoyaltyCardResultScreen extends StatefulWidget {
  final LoyaltyCard card;

  const LoyaltyCardResultScreen({super.key, required this.card});

  @override
  State<LoyaltyCardResultScreen> createState() => _LoyaltyCardResultScreenState();
}

class _LoyaltyCardResultScreenState extends State<LoyaltyCardResultScreen> {
  final _pdfService = LoyaltyCardPdfService();
  bool _isProcessing = false;

  LoyaltyCard get card => widget.card;

  Future<void> _handlePrint() async {
    setState(() => _isProcessing = true);
    try {
      await _pdfService.printCard(card);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<void> _handleShare() async {
    setState(() => _isProcessing = true);
    try {
      await _pdfService.shareCard(card);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Carte créée'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 12),
              Row(
                children: const [
                  Icon(Icons.check_circle, color: Colors.green, size: 22),
                  SizedBox(width: 8),
                  Text(
                    'Carte de fidélité générée avec succès',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              LoyaltyCardWidget(card: card),
              const SizedBox(height: 32),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _isProcessing ? null : _handlePrint,
                      icon: const Icon(Icons.print_outlined),
                      label: const Text('Imprimer (PDF)'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _isProcessing ? null : _handleShare,
                      icon: const Icon(Icons.share_outlined),
                      label: const Text('Partager (PDF)'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    child: Text('Terminer'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
