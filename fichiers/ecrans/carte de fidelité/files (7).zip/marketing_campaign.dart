import 'customer_profile.dart';
import 'product_ref.dart';

enum SegmentType { all, inactiveSince, repeatCustomers, oneTimeNoReturn }

enum MarketingChannel { whatsapp, sms }

/// Définit un segment de clients ciblable depuis l'écran marketing.
/// Utiliser les constructeurs nommés pour les cas prévus par Ben :
/// tous les clients, inactifs depuis X, clients fidèles (achats
/// répétés), clients venus une seule fois et jamais revenus.
class CustomerSegment {
  final SegmentType type;
  final Duration? inactiveDuration;
  final String label;

  const CustomerSegment._(this.type, this.label, {this.inactiveDuration});

  factory CustomerSegment.all() =>
      const CustomerSegment._(SegmentType.all, 'Tous les clients');

  factory CustomerSegment.inactiveSince(Duration duration, {String? label}) =>
      CustomerSegment._(
        SegmentType.inactiveSince,
        label ?? 'Inactifs depuis ${duration.inDays ~/ 30} mois',
        inactiveDuration: duration,
      );

  factory CustomerSegment.repeatCustomers() => const CustomerSegment._(
        SegmentType.repeatCustomers,
        'Clients fidèles (plusieurs achats)',
      );

  factory CustomerSegment.oneTimeNoReturn({Duration? minInactivity}) =>
      CustomerSegment._(
        SegmentType.oneTimeNoReturn,
        'Achat unique, jamais revenus',
        inactiveDuration: minInactivity ?? const Duration(days: 60),
      );

  /// Segments prédéfinis suggérés dans l'UI (2 mois / 6 mois / fidèles / ponctuels).
  static List<CustomerSegment> presets() => [
        CustomerSegment.all(),
        CustomerSegment.inactiveSince(const Duration(days: 60), label: 'Pas revenus depuis 2 mois'),
        CustomerSegment.inactiveSince(const Duration(days: 180), label: 'Pas revenus depuis 6 mois'),
        CustomerSegment.repeatCustomers(),
        CustomerSegment.oneTimeNoReturn(),
      ];
}

/// Représente une campagne marketing prête à être envoyée :
/// segment ciblé, produit en promotion (optionnel), message et canal.
class MarketingCampaign {
  final CustomerSegment segment;
  final ProductRef? promotedProduct;
  final String message;
  final MarketingChannel channel;
  final List<CustomerProfile> recipients;

  const MarketingCampaign({
    required this.segment,
    required this.message,
    required this.channel,
    required this.recipients,
    this.promotedProduct,
  });
}
