import 'package:flutter/material.dart';
import '../models/customer_profile.dart';
import '../models/marketing_campaign.dart';
import '../models/product_ref.dart';
import '../services/campaign_sender_service.dart';
import '../services/customer_segmentation_service.dart';
import '../widgets/channel_selector.dart';
import '../widgets/customer_segment_selector.dart';
import '../widgets/product_picker.dart';

/// Écran "Marketing / Retargeting clients".
///
/// Étapes : choisir le segment de clients à cibler → choisir un
/// produit en promotion (optionnel) → rédiger le message → choisir
/// le canal (WhatsApp/SMS) → lancer l'envoi.
///
/// [allCustomers] et [products] sont à fournir depuis vos données
/// existantes (liste clients déjà en place côté Kassa, catalogue produits).
class MarketingCampaignScreen extends StatefulWidget {
  final List<CustomerProfile> allCustomers;
  final List<ProductRef> products;

  const MarketingCampaignScreen({
    super.key,
    required this.allCustomers,
    required this.products,
  });

  @override
  State<MarketingCampaignScreen> createState() => _MarketingCampaignScreenState();
}

class _MarketingCampaignScreenState extends State<MarketingCampaignScreen> {
  final _segmentationService = CustomerSegmentationService();
  final _messageController = TextEditingController();

  CustomerSegment _segment = CustomerSegment.all();
  ProductRef? _selectedProduct;
  MarketingChannel _channel = MarketingChannel.whatsapp;

  List<CustomerProfile> get _recipients =>
      _segmentationService.filter(widget.allCustomers, _segment);

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  void _insertProductInMessage() {
    if (_selectedProduct == null) return;
    final promo = 'Profitez de notre promotion sur ${_selectedProduct!.name} !';
    setState(() {
      _messageController.text = _messageController.text.isEmpty
          ? promo
          : '${_messageController.text}\n$promo';
    });
  }

  void _launchCampaign() {
    if (_messageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Écrivez un message avant d\'envoyer')),
      );
      return;
    }
    if (_recipients.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aucun client ne correspond à ce segment')),
      );
      return;
    }

    final campaign = MarketingCampaign(
      segment: _segment,
      promotedProduct: _selectedProduct,
      message: _messageController.text.trim(),
      channel: _channel,
      recipients: _recipients,
    );

    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => CampaignSendingScreen(campaign: campaign)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Retargeting clients')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const _SectionTitle('1. Sélectionner les clients'),
            const SizedBox(height: 8),
            CustomerSegmentSelector(
              selected: _segment,
              onSelected: (s) => setState(() => _segment = s),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.4),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.groups_outlined, size: 18),
                  const SizedBox(width: 8),
                  Text('${_recipients.length} client(s) sélectionné(s)'),
                ],
              ),
            ),

            const SizedBox(height: 28),
            const _SectionTitle('2. Produit en promotion'),
            const SizedBox(height: 8),
            ProductPicker(
              products: widget.products,
              selected: _selectedProduct,
              onSelected: (p) => setState(() => _selectedProduct = p),
            ),
            if (_selectedProduct != null)
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: _insertProductInMessage,
                  icon: const Icon(Icons.auto_awesome, size: 18),
                  label: const Text('Insérer une phrase promo dans le message'),
                ),
              ),

            const SizedBox(height: 20),
            const _SectionTitle('3. Message'),
            const SizedBox(height: 8),
            TextField(
              controller: _messageController,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'Ex: Bonjour ! Nous avons une nouvelle promotion pour vous...',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 28),
            const _SectionTitle('4. Canal d\'envoi'),
            const SizedBox(height: 8),
            ChannelSelector(
              selected: _channel,
              onChanged: (c) => setState(() => _channel = c),
            ),

            const SizedBox(height: 32),
            FilledButton.icon(
              onPressed: _launchCampaign,
              icon: const Icon(Icons.send_rounded),
              label: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Text(
                  'Envoyer à ${_recipients.length} client(s)',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold));
  }
}

/// Écran de déroulement de l'envoi : fait défiler les destinataires un
/// par un et ouvre WhatsApp/SMS pré-rempli pour chacun (mode assisté,
/// voir README pour le passage à un envoi 100% automatique via API).
class CampaignSendingScreen extends StatefulWidget {
  final MarketingCampaign campaign;

  const CampaignSendingScreen({super.key, required this.campaign});

  @override
  State<CampaignSendingScreen> createState() => _CampaignSendingScreenState();
}

class _CampaignSendingScreenState extends State<CampaignSendingScreen> {
  final CampaignSenderService _sender = AssistedQueueCampaignSender();
  int _index = 0;
  int _sentCount = 0;
  bool _isSending = false;

  CustomerProfile get _current => widget.campaign.recipients[_index];
  bool get _isDone => _index >= widget.campaign.recipients.length;

  Future<void> _sendToCurrent() async {
    setState(() => _isSending = true);
    final step = await _sender.sendToCustomer(widget.campaign, _current);
    setState(() {
      _isSending = false;
      if (step.launched) _sentCount++;
    });
  }

  void _next() {
    setState(() => _index++);
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.campaign.recipients.length;
    final channelLabel =
        widget.campaign.channel == MarketingChannel.whatsapp ? 'WhatsApp' : 'SMS';

    return Scaffold(
      appBar: AppBar(title: Text('Envoi $channelLabel')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: _isDone
              ? _buildSummary(total)
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    LinearProgressIndicator(value: total == 0 ? 0 : _index / total),
                    const SizedBox(height: 8),
                    Text('Client ${_index + 1} sur $total', style: const TextStyle(color: Colors.black54)),
                    const SizedBox(height: 24),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_current.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 4),
                            Text(_current.phoneNumber, style: const TextStyle(color: Colors.black54)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Chaque envoi doit être confirmé manuellement dans '
                      '$channelLabel (limitation imposée par la plateforme). '
                      'Appuyez sur "Ouvrir $channelLabel", envoyez le message, '
                      'puis revenez ici pour passer au client suivant.',
                      style: const TextStyle(fontSize: 13, color: Colors.black54),
                    ),
                    const Spacer(),
                    FilledButton.icon(
                      onPressed: _isSending ? null : _sendToCurrent,
                      icon: const Icon(Icons.open_in_new_rounded),
                      label: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        child: Text('Ouvrir $channelLabel'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton(
                      onPressed: _next,
                      child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        child: Text('Client suivant'),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildSummary(int total) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.check_circle, color: Colors.green, size: 48),
        const SizedBox(height: 16),
        Text(
          '$_sentCount / $total envois lancés',
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 24),
        FilledButton(
          onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Text('Terminer'),
          ),
        ),
      ],
    );
  }
}
