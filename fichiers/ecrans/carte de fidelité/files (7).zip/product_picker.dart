import 'package:flutter/material.dart';
import '../models/product_ref.dart';

class ProductPicker extends StatelessWidget {
  final List<ProductRef> products;
  final ProductRef? selected;
  final ValueChanged<ProductRef?> onSelected;

  const ProductPicker({
    super.key,
    required this.products,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField<ProductRef>(
          value: selected,
          decoration: const InputDecoration(
            labelText: 'Produit en promotion (optionnel)',
            border: OutlineInputBorder(),
            prefixIcon: Icon(Icons.local_offer_outlined),
          ),
          items: [
            const DropdownMenuItem<ProductRef>(
              value: null,
              child: Text('Aucun produit spécifique'),
            ),
            ...products.map(
              (p) => DropdownMenuItem<ProductRef>(
                value: p,
                child: Text('${p.name} — ${p.price} FCFA'),
              ),
            ),
          ],
          onChanged: onSelected,
        ),
      ],
    );
  }
}
