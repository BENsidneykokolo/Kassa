/// Référence légère vers un produit du catalogue Kassa, utilisée
/// uniquement pour l'affichage dans le sélecteur de promotion.
///
/// À remplacer/mapper vers votre modèle de produit réel du package
/// catalogue partagé (Kassa -> catalogue -> LOBA).
class ProductRef {
  final String id;
  final String name;
  final num price;
  final String? imageUrl;

  const ProductRef({
    required this.id,
    required this.name,
    required this.price,
    this.imageUrl,
  });
}
